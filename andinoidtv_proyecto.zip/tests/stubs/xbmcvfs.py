import os, shutil
ROOT = os.environ.get('KODI_HOME', '/tmp/kodihome')
def translatePath(p):
    return p.replace('special://profile/', ROOT + '/userdata/').replace('special://temp/', ROOT + '/temp/').replace('special://home/', ROOT + '/').replace('special://thumbnails/', ROOT + '/userdata/Thumbnails/').replace('special://database/', ROOT + '/userdata/Database/')
def exists(p): return os.path.exists(translatePath(p))
def mkdirs(p): os.makedirs(translatePath(p), exist_ok=True); return True
def copy(a, b): shutil.copy(translatePath(a), translatePath(b)); return True
class File:
    def __init__(self, p, mode='r'): self.f = open(translatePath(p), mode, encoding='utf-8')
    def __enter__(self): return self
    def __exit__(self, *a): self.f.close()
    def read(self): return self.f.read()
    def write(self, t): self.f.write(t); return True
