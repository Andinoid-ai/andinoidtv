SETTINGS = {}
class Addon:
    def __init__(self, id='plugin.program.andinoidtv'):
        import xbmc
        if id != 'plugin.program.andinoidtv' and id not in xbmc.STATE['addons']: raise RuntimeError('no addon')
        self.id = id
    def getAddonInfo(self, k):
        import os
        return {'id': self.id, 'path': os.environ['ADDON_SRC'], 'icon': 'icon.png', 'fanart': 'fanart.jpg'}.get(k, '')
    def setSetting(self, k, v): SETTINGS[(self.id, k)] = v
    setSettingBool = setSettingInt = setSettingString = setSetting
    def getSetting(self, k): return str(SETTINGS.get((self.id, k), '')).lower()
