class Dialog:
    def yesno(self, *a, **k): print('YESNO', a[0]); return True
    def ok(self, h, m): print('OK', h, '|', m)
    def notification(self, *a): print('NOTIFY', a[:2])
    def textviewer(self, h, t): print('TEXT', h, '\n', t)
class DialogProgress:
    def create(self, *a): pass
    def update(self, p, m=''): print('PROGRESS', p, m.replace('\n', ' | '))
    def close(self): pass
class ListItem:
    def __init__(self, l): self.l = l
    def setArt(self, a): pass
    def getVideoInfoTag(self):
        class T:
            def setPlot(s, p): pass
        return T()
