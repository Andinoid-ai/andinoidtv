import json, os
LOGINFO, LOGWARNING, LOGERROR, LOGDEBUG = 1, 2, 3, 0
CALLS = []
STATE = {'skin': 'skin.estuary', 'addons': {'skin.arctic.fuse.3', 'plugin.video.themoviedb.helper', 'script.skinvariables', 'plugin.video.jacktook'}, 'settings': {'lookandfeel.skin': 'skin.estuary', 'locale.language': 'resource.language.en_gb'}}
def log(msg, level=0): print('LOG', msg)
def executebuiltin(cmd, wait=False):
    CALLS.append(cmd)
    if cmd.startswith('InstallAddon('): STATE['addons'].add(cmd[13:-1])
def getCondVisibility(cond):
    if cond.startswith('System.HasAddon('): return cond[16:-1] in STATE['addons']
    return False
def getSkinDir(): return STATE['settings']['lookandfeel.skin']
def getInfoLabel(l): return '900MB'
def executeJSONRPC(q):
    q = json.loads(q); m = q['method']; p = q.get('params', {})
    if m == 'Settings.SetSettingValue': STATE['settings'][p['setting']] = p['value']; return json.dumps({'result': True})
    if m == 'Settings.GetSettingValue': return json.dumps({'result': {'value': STATE['settings'].get(p['setting'])}})
    if m == 'Addons.GetAddonDetails': return json.dumps({'result': {'addon': {'enabled': True}}})
    if m == 'Addons.GetAddons': return json.dumps({'result': {'addons': [{'addonid': a, 'name': a.split('.')[-1], 'enabled': True} for a in STATE['addons']]}})
    return json.dumps({'result': 'OK'})
class Monitor:
    def waitForAbort(self, s=0): return False
    def abortRequested(self): return False
