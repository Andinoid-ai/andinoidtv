ITEMS = []
def addDirectoryItem(h, u, li, isFolder=False): ITEMS.append((u, li.l)); return True
def endOfDirectory(h, **k): print('END', ITEMS)
