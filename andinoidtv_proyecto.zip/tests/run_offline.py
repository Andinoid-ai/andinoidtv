import os, sys, json, runpy
SRC = os.path.abspath('src/plugin.program.andinoidtv')
os.environ['ADDON_SRC'] = SRC
sys.path[:0] = [os.path.abspath('tests/stubs'), SRC]
import xbmc, xbmcaddon
from resources.lib import apply, tools, catalog, nodes
apply.run()
print('SETTINGS', json.dumps(xbmc.STATE['settings'], ensure_ascii=False))
print('ADDON SETTINGS', xbmcaddon.SETTINGS)
print('BUILTINS', xbmc.CALLS)
tools.diagnose()
tools.repair_sources()
catalog.open_addon('palantir')
catalog.open_addon('plutotv')
catalog.open_addon('magellan')
sys.argv = ['plugin://plugin.program.andinoidtv/', '1', '']
runpy.run_path(os.path.join(SRC, 'default.py'))
d = '/tmp/kodihome/userdata/addon_data/script.skinvariables/nodes/skin.arctic.fuse.3'
print(sorted(os.listdir(d)))
print(open(os.path.join(d, 'skinvariables-shortcut-homewidgets.json')).read()[:600])
print(os.listdir('/tmp/kodihome/userdata/addon_data/plugin.video.themoviedb.helper/players'))
